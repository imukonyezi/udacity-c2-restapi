"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isEmpty = (obj) => {
    for (let k in obj) {
        if (obj.hasOwnProperty(k)) {
            return false;
        }
    }
    return true;
};
//# sourceMappingURL=commons.js.map